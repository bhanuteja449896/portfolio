import Intro from "./Intro";
import AboutMe from "./AboutMe";
import TechIKnow from "./TechIKnow";
import ResumeSummary from "./ResumeSummary";
import PortfolioImages from "./PortfolioImages";
import SocialMedia from "./SocialMedia";


export { Intro,AboutMe,TechIKnow,ResumeSummary,PortfolioImages,SocialMedia }